"""playerproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from playerapp import views as playerappViews
from rest_framework_simplejwt.views import (TokenObtainPairView,TokenRefreshView)
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',playerappViews.index,name='index'),
    path('home/',playerappViews.home,name='home'),
    path('welcome/',playerappViews.welcome,name='welcome'),
    path('addplayer/',playerappViews.addPlayer,name='addplayer'),
    path('editplayer/<int:player_id>/',playerappViews.editPlayer,name='editplayer'),
    path('deleteplayer/<int:player_id>/',playerappViews.deletePlayer,name='deleteplayer'),
    path('api/',include('playerapp.api_urls')),
    path('api/token/',TokenObtainPairView.as_view()),
    path('api/token/refresh/',TokenRefreshView.as_view()),

]
