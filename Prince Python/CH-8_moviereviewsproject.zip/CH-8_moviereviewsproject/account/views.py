from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login,logout
from django.contrib.auth.models import User
from django.shortcuts import redirect
from django.db import IntegrityError

# Create your views here.
def signupaccount(request):
    if request.method=='GET':
        return render(request,'signupaccount.html',{'form':UserCreationForm})
    else:
        if request.POST['password1']==request.POST['password2']:
            try:
                user=User.objects.create_user(request.POST['username'],password=request.POST['password1'])
                user.save()
                login(request,user)
                return redirect('home')
            except IntegrityError:
                return render(request,'signupaccount.html',{'error':'Username already taken','form':UserCreationForm})
        else:
            return render(request,'signupaccount.html',{'error':'Password do not match','form':UserCreationForm}) 

def logoutaccount(request):
    logout(request)
    return redirect('home')        