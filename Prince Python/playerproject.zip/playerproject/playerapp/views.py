from django.shortcuts import render
from django.shortcuts import redirect,get_object_or_404
from .models import Players

# Create your views here.
def index(request):
    return render(request,'index.html')

def home(request):
    search=request.GET.get('search')
    if search:
        players=Players.objects.filter(name__icontains=search)
    else:
        players=Players.objects.all()
    return render(request,'home.html',{'players':players})

def welcome(request):
    return render(request,'welcome.html')

def addPlayer(request):
    if request.method=='GET':
        return render(request,'add_player.html')   
    else:
        try:
            name=request.POST.get('name')
            innings=request.POST.get('innings')
            runs=request.POST.get('runs')
            Players.objects.create(name=name,innings=innings,runs=runs)
            return redirect('home')
        except ValueError:
            return render(request,'add_player.html')
        
def editPlayer(request,player_id):
    player=get_object_or_404(Players,id=player_id)
    if request.method=='GET':
        return render(request,'edit_player.html')   
    else:
        try:
            player.name=request.POST.get('name')
            player.innings=request.POST.get('innings')
            player.runs=request.POST.get('runs')
            player.save()
            return redirect('home')
        except ValueError:
            return render(request,'edit_player.html')
        
def deletePlayer(request,player_id):
    player=get_object_or_404(Players,id=player_id)
    player.delete()
    return redirect('home')     


from rest_framework import viewsets
from .models import Players
from .serializers import PlayerSerializer

class PlayerViewSet(viewsets.ModelViewSet):
    queryset=Players.objects.all()
    serializer_class=PlayerSerializer