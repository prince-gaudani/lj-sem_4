from django.db import models

# Create your models here.
class Players(models.Model):
    name=models.TextField(max_length=100)
    innings=models.TextField()
    runs=models.TextField()